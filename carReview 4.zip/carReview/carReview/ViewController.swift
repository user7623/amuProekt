//
//  ViewController.swift
//  carReview
//
//  Created by iIdiot on 1/3/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse
@IBDesignable

class ViewController: UIViewController {

    @IBOutlet var usernameTextField: UITextField!
    
    
    @IBOutlet var passwordTextField: UITextField!
    @IBAction func signupButton(_ sender: UIButton) {
        performSegue(withIdentifier: "toRegisterView", sender: nil)
    }
    
    @IBAction func loginButton(_ sender: UIButton) {
        
        print("password/username" + passwordTextField.text! + usernameTextField.text!)
        
        //dodaj animacija spinner
        //let sv = UIViewController.displaySpinner(onView: self.view)
        performSegue(withIdentifier: "toClientViewSeg", sender: nil)
        
        PFUser.logInWithUsername(inBackground: usernameTextField.text!, password: passwordTextField.text!) { (user, error) in
            // activityIndicator.stopAnimating()
           // UIViewController.removeSpinner(spinner: sv)
            UIApplication.shared.endIgnoringInteractionEvents()
            if let error = error {
                let errorString = error.localizedDescription
                self.createAlert(title: "Error logging in", message: errorString)
                print(errorString)
            } else {
                print("Log in success!")
                //proveri tip na korisnik
                if let loggedIn = user
                {
                    userField = loggedIn["admin"] as! String
                    userEmail = loggedIn["email"] as! String
                    userCars = loggedIn["cars"] as! String
                    print("field: " + userField)
                    if(userField == "YES" )
                    {
                        print("segue to administrator view")
                        self.performSegue(withIdentifier: "toAdminViewSeg", sender: self)
                    }else{
                        print("segue to client view")
                        self.performSegue(withIdentifier: "toClientViewSeg", sender: self)
                    }
                }
            }
        }

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.setTwoGradients(colorOne: UIColor.green, colorTwo: UIColor.white)
    }
    
    func createAlert(title: String, message: String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert )
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
    }
}


