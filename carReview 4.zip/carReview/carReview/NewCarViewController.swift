//
//  NewCarViewController.swift
//  carReview
//
//  Created by iIdiot on 1/5/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse
class NewCarViewController: UIViewController {

    var errorMessageText = "!"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.setTwoGradients(colorOne: UIColor.green, colorTwo: UIColor.white)
    }
    
    @IBAction func logoutButton(_ sender: UIButton) {
        //let sv = UIViewController.displaySpinner(onView: self.view)
        PFUser.logOutInBackground{(error: Error?) in
            //UIViewController.removeSpinner(spinner: sv)
            if error == nil
            {
                print("logout success")
                self.performSegue(withIdentifier: "toSignIn", sender: self)
            }else{
                if error?.localizedDescription != nil
                {
                    print("error: " + (error?.localizedDescription)!)
                }else{
                    print("unkonw error!!!")
                }
            }
        }
        //performSegue(withIdentifier: "toSignIn", sender: nil)
    }
    
    @IBAction func carsButton(_ sender: UIButton) {
        performSegue(withIdentifier: "newCarToCarsSeg", sender: nil)
    }
    
    @IBOutlet var makeTextField: UITextField!
    @IBOutlet var modelTextField: UITextField!
    @IBOutlet var yearTextField: UITextField!
    @IBOutlet var descriptionTextField: UITextField!
    @IBOutlet var priceTextField: UITextField!
    @IBOutlet var videoIdTextField: UITextField!
    @IBOutlet var theImageView: UIImageView!
    
    @IBAction func choosePhotoButton(_ sender: UIButton) {
        
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc, animated: true)
        
        
        /*
         
         let vc = UIImagePickerController()
         vc.sourceType = .photoLibrary
         vc.delegate = self
         vc.allowsEditing = true
         present(vc, animated: true)
         */

    }
    @IBAction func uploadButton(_ sender: UIButton) {
        if makeTextField.text! == ""
        {
            errorMessageText = "Enter value for make"
        }
        else if modelTextField.text! == ""
        {
            errorMessageText = "Enter value for model"
        }
        else if yearTextField.text! == ""
        {
            errorMessageText = "Enter value for year"
        }
        else if descriptionTextField.text! == ""
        {
            errorMessageText = "Enter value for description"
        }
        else if videoIdTextField.text! == ""
        {
            errorMessageText = "Enter value for videoId"
        }
        else if priceTextField.text! == ""
        {
            errorMessageText = "Enter value for price"
        }
        else
        {
            print("Posting...")
            let carPost = PFObject(className: "car")
            carPost["make"] = makeTextField.text!
            carPost["model"] = modelTextField.text!
            carPost["year"] = yearTextField.text!
            carPost["description"] = descriptionTextField.text!
            carPost["price"] = priceTextField.text!
            carPost["videoId"] = videoIdTextField.text!
            //ne debagirano
            let image:UIImage? = theImageView.image
            if let jobPhoto = image{
                print("image detected")
                guard let imageData = jobPhoto.pngData() else{
                    return
                }
                carPost["carImage"] = imageData
                let df = DateFormatter()
                df.dateFormat = "dd-MM-YYYY hh-mm-ss"
                let theDate = df.string(from: Date())
                carPost["postedOn"] = theDate
                print("image added to finished job, ready for posting")
                carPost.saveInBackground {(success: Bool, error: Error?) in
                    if success
                    {
                        print("successfuly posted the car post")
                        self.createAlert(title: "Success", message: "The car post is uploaded to server")
                    }
                    else
                    {
                        if error?.localizedDescription != nil
                        {
                            print("ERROR!!!: " + (error?.localizedDescription)!)
                            self.createAlert(title: "error", message: (error?.localizedDescription)!)
                        }
                        else
                        {
                            print("ERROR!!!: unknown")
                            self.createAlert(title: "error", message: "unkown")
                        }
                        self.resetAdminView()
                    }
                }
            }
        }
        print("Uploaded the car post")
        resetAdminView()
    }
    
    
    func resetAdminView()
    {
        makeTextField.text! = ""
        modelTextField.text! = ""
        yearTextField.text! = ""
        priceTextField.text! = ""
        descriptionTextField.text! = ""
    }
    
    func createAlert(title: String, message: String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert )
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
}
extension NewCarViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        
        if let image = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")]as? UIImage{
            theImageView.image = image
        }
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
