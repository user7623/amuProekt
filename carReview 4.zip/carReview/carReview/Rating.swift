//
//  Rating.swift
//  carReview
//
//  Created by iIdiot on 1/7/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import Foundation
import UIKit

struct RatingView: View {
    @Binding var rating: Int
    var label = ""
    var maximumRating = 5
    
    var body: some View
    {
        Text("Hello world")
    }
}
