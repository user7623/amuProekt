//
//  ClientViewController.swift
//  carReview
//
//  Created by iIdiot on 1/5/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse

var selectedCarByClient: PFObject?
var carImageSelectedGlobal: UIImage?
class ClientViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var firstAppear = true
    var isFilter = false
    @IBOutlet var secondClientView: UIView!
    @IBAction func logoutButton(_ sender: UIButton) {
        
        //let sv = UIViewController.displaySpinner(onView: self.view)
        PFUser.logOutInBackground{(error: Error?) in
            //UIViewController.removeSpinner(spinner: sv)
            if error == nil
            {
                print("logout success")
                self.performSegue(withIdentifier: "clientLogoutSeg", sender: self)
            }else{
                if error?.localizedDescription != nil
                {
                    print("error: " + (error?.localizedDescription)!)
                }else{
                    print("unkonw error!!!")
                }
            }
        }
        //performSegue(withIdentifier: "clientLogoutSeg", sender: nil)
    }
    @IBOutlet var logoImageView: UIImageView!
    
    var carsList: [PFObject] = []
    var carsDetail: [PFObject] = []

    @IBOutlet var carsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        secondClientView.setTwoDiagonalGradients(colorOne: UIColor.red, colorTwo: UIColor.blue)
        logoImageView.layer.cornerRadius = logoImageView.frame.height/2
        logoImageView.clipsToBounds = true
        carsTableView.dataSource = self
        carsTableView.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        if firstAppear{
            print("view did appear")
            let carQ = PFQuery(className: "car")
            carQ.findObjectsInBackground(block: {(result: [PFObject]? , error: Error?)-> Void in
                if let foundCars = result //as? [PFObject]
                {
                    self.carsDetail = foundCars
                    if self.carsDetail.count <= 0 {print("problem, no cars found!")}
                    else{
                        //var carCount = self.carsDetail.count
                        self.carsList = self.carsDetail
                        /*while carCount > 0
                        {
                            self.carsList.append(self.carsDetail[carCount - 1])
                            carCount = carCount - 1
                        }*/
                        print("info loaded for car list")
                        
                        self.carsTableView.reloadData()
                        print("reloading table data")
                    }
                }else
                {
                    if let erMsg = error
                    {
                        print(erMsg.localizedDescription)
                    }
                    else
                    {
                        print("Problem!! Unknown error!!!")
                    }
                }
            })
            //carsTableView.reloadData()
        }
        firstAppear = false
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return carsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "KelijaDva", for: indexPath)
        //TODO debagiraj !!!
        var countCars = carsList.count
        var carObj: PFObject?
        print("entered cell for row at")
        
        print("found " + "\(countCars)")
        
                print("----------------------------------------")
                carObj = self.carsList[indexPath.row]
                let dataP = self.carsList[indexPath.row].object(forKey: "carImage") as! Data
        
                //let data = carObj?.object(forKey: "carImage") as! Data
                let image = UIImage(data: dataP)
            
                cell.imageView?.image = image
                print("placed image for car")
                carImageSelectedGlobal = image
                print("!")
                print("placing text for cell number " + "\(countCars)")
                print("name " + "\(carObj!.object(forKey: "model") as! String)")
            
                var carInfoP = self.carsList[indexPath.row].object(forKey: "model") as! String
                carInfoP.append(" ")
                carInfoP.append(self.carsList[indexPath.row].object(forKey: "make") as! String)
                carInfoP.append(" ")
                carInfoP.append(self.carsList[indexPath.row].object(forKey: "year") as! String)
                cell.detailTextLabel?.text! = carInfoP
                cell.textLabel?.text! = carInfoP
                countCars = countCars - 1
                carInfoP = ""
        
        if self.carsList.count > 0 {
            print("cars count is bigger than 0")
        }else{
            cell.textLabel?.text! = "no finished jobs"
        }
        print("returning cell")
        
        if indexPath.row == carsList.count{isFilter = false
            print("0000000000")
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("seletion detected")
        selectedCarByClient = carsList[indexPath.row]
        let data = carsList[indexPath.row].object(forKey: "carImage") as! Data
        
        //carImageSelectedGlobal = UIImage(data: data)
        print("segue to car details view")
        performSegue(withIdentifier: "clientViewToCarDetailsSeg", sender: nil)
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            carsList[indexPath.row].deleteInBackground()
            carsList.remove(at: indexPath.row)
            carsTableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.bottom)
            //  carsTableView.reloadData()
        }
    }
    @IBAction func myCarsButton(_ sender: UIButton) {
        print("to my cars view")
        performSegue(withIdentifier: "clientViewToMyCarsSeg", sender: nil)
    }
}
