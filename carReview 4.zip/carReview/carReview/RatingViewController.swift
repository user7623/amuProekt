//
//  RatingViewController.swift
//  carReview
//
//  Created by iIdiot on 1/7/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse

class RatingViewController: UIViewController {
    
    @IBOutlet var navBar: UINavigationItem!
    @IBOutlet var relLabel: UILabel!
    @IBOutlet var relSlider: UISlider!
    @IBOutlet var fuelLabel: UILabel!
    @IBOutlet var fuelSlider: UISlider!
    @IBOutlet var looksLabel: UILabel!
    @IBOutlet var looksSlider: UISlider!
    @IBOutlet var valueLabel: UILabel!
    @IBOutlet var valueSlider: UISlider!
    @IBOutlet var handlingLabel: UILabel!
    @IBOutlet var handlingSlider: UISlider!
    @IBOutlet var funLabel: UILabel!
    @IBOutlet var funSlider: UISlider!
    
    var reliabilityValue = 0
    var fuelValue = 0
    var looksValue = 0
    var valueValue = 0
    var handlingValue = 0
    var funValue = 0
    
    @IBAction func relSliderAction(_ sender: UISlider) {
        let vrednost = sender.value
        print("vrednost: " + "\(vrednost)")
        if vrednost <= 0.2
        {
            relLabel.text! = "Reliability: Poor"
            reliabilityValue = 1
            relSlider.tintColor = UIColor.red
            relSlider.thumbTintColor = UIColor.red
        }
        else if (vrednost > 0.2) && (vrednost <= 0.4)
        {
            relLabel.text! = "Reliability: Bad"
            reliabilityValue = 2
            relSlider.tintColor = UIColor.orange
            relSlider.thumbTintColor = UIColor.orange
        }
        else if (vrednost > 0.4) && (vrednost <= 0.6)
        {
            relLabel.text! = "Reliability: Mediocore"
            reliabilityValue = 3
            relSlider.tintColor = UIColor.blue
            relSlider.thumbTintColor = UIColor.blue
        }
        else if (vrednost > 0.6) && (vrednost <= 0.8)
        {
            relLabel.text! = "reliability: Good"
            reliabilityValue = 4
            relSlider.tintColor = UIColor.yellow
            relSlider.thumbTintColor = UIColor.yellow
        }else{
            reliabilityValue = 5
            relLabel.text! = "Reliability: Excellent"
            relSlider.tintColor = UIColor.green
            relSlider.thumbTintColor = UIColor.green
        }
    }
    
    @IBAction func fuelSliderAction(_ sender: UISlider) {
        let vrednost = sender.value
        if vrednost <= 0.2
        {
            fuelLabel.text! = "Fuel economy: Poor"
            fuelValue = 1
            fuelSlider.tintColor = UIColor.red
            fuelSlider.thumbTintColor = UIColor.red
        }
        else if (vrednost > 0.2) && (vrednost <= 0.4)
        {
            fuelLabel.text! = "Fuel eco. : Bad"
            fuelValue = 2
            fuelSlider.tintColor = UIColor.orange
            fuelSlider.thumbTintColor = UIColor.orange
        }
        else if (vrednost > 0.4) && (vrednost <= 0.6)
        {
            fuelLabel.text! = "Fuel eco.: Mediocore"
            fuelValue = 3
            fuelSlider.tintColor = UIColor.blue
            fuelSlider.thumbTintColor = UIColor.blue
        }
        else if (vrednost > 0.6) && (vrednost <= 0.8)
        {
            fuelLabel.text! = "Fuel eco.: Good"
            fuelValue = 4
            fuelSlider.tintColor = UIColor.yellow
            fuelSlider.thumbTintColor = UIColor.yellow
        }else{
            fuelValue = 5
            fuelLabel.text! = "Fuel eco.: Excellent"
            fuelSlider.tintColor = UIColor.green
            fuelSlider.thumbTintColor = UIColor.green
        }
    }
    
    @IBAction func looksSliderAction(_ sender: UISlider) {
        let vrednost = sender.value
        if vrednost <= 0.2
        {
            looksLabel.text! = "Looks: Poor"
            looksValue = 1
            looksSlider.tintColor = UIColor.red
            looksSlider.thumbTintColor = UIColor.red
        }
        else if (vrednost > 0.2) && (vrednost <= 0.4)
        {
            looksLabel.text! = "Looks: Bad"
            looksValue = 2
            looksSlider.tintColor = UIColor.orange
            looksSlider.thumbTintColor = UIColor.orange
        }
        else if (vrednost > 0.4) && (vrednost <= 0.6)
        {
            looksLabel.text! = "Looks: Mediocore"
            looksValue = 3
            looksSlider.tintColor = UIColor.blue
            looksSlider.thumbTintColor = UIColor.blue
        }
        else if (vrednost > 0.6) && (vrednost <= 0.8)
        {
            looksLabel.text! = "Looks: Good"
            looksValue = 4
            looksSlider.tintColor = UIColor.yellow
            looksSlider.thumbTintColor = UIColor.yellow
        }else{
            looksValue = 5
            looksLabel.text! = "Looks: Excellent"
            looksSlider.tintColor = UIColor.green
            looksSlider.thumbTintColor = UIColor.green
        }
    }
    
    @IBAction func valueSliderAction(_ sender: UISlider) {
        let vrednost = sender.value
        if vrednost <= 0.2
        {
            valueLabel.text! = "Value: Poor"
            valueValue = 1
            valueSlider.tintColor = UIColor.red
            valueSlider.thumbTintColor = UIColor.red
        }
        else if (vrednost > 0.2) && (vrednost <= 0.4)
        {
            valueLabel.text! = "Value: Bad"
            valueValue = 2
            valueSlider.tintColor = UIColor.orange
            valueSlider.thumbTintColor = UIColor.orange
        }
        else if (vrednost > 0.4) && (vrednost <= 0.6)
        {
            valueLabel.text! = "Value: Mediocore"
            valueValue = 3
            valueSlider.tintColor = UIColor.blue
            valueSlider.thumbTintColor = UIColor.blue
        }
        else if (vrednost > 0.6) && (vrednost <= 0.8)
        {
            valueLabel.text! = "Value: Good"
            valueValue = 4
            valueSlider.tintColor = UIColor.yellow
            valueSlider.thumbTintColor = UIColor.yellow
        }else{
            valueValue = 5
            valueLabel.text! = "Value: Excellent"
            valueSlider.tintColor = UIColor.green
            valueSlider.thumbTintColor = UIColor.green
        }
    }
    @IBAction func handlingSliderAction(_ sender: UISlider) {
        
        let vrednost = sender.value
        if vrednost <= 0.2
        {
            handlingLabel.text! = "Handling: Poor"
            handlingValue = 1
            handlingSlider.tintColor = UIColor.red
            handlingSlider.thumbTintColor = UIColor.red
        }
        else if (vrednost > 0.2) && (vrednost <= 0.4)
        {
            handlingLabel.text! = "Handling: Bad"
            handlingValue = 2
            handlingSlider.tintColor = UIColor.orange
            handlingSlider.thumbTintColor = UIColor.orange
        }
        else if (vrednost > 0.4) && (vrednost <= 0.6)
        {
            handlingLabel.text! = "Handling: Mediocore"
            handlingValue = 3
            handlingSlider.tintColor = UIColor.blue
            handlingSlider.thumbTintColor = UIColor.blue
        }
        else if (vrednost > 0.6) && (vrednost <= 0.8)
        {
            handlingLabel.text! = "Handling: Good"
            handlingValue = 4
            handlingSlider.tintColor = UIColor.yellow
            handlingSlider.thumbTintColor = UIColor.yellow
        }else{
            handlingValue = 5
            handlingLabel.text! = "handling: Excellent"
            handlingSlider.tintColor = UIColor.green
            handlingSlider.thumbTintColor = UIColor.green
        }
    }
    
    @IBAction func funSliderAction(_ sender: UISlider) {
        
        let vrednost = sender.value
        if vrednost <= 0.2
        {
            funLabel.text! = "Fun: Poor"
            funValue = 1
            funSlider.tintColor = UIColor.red
            funSlider.thumbTintColor = UIColor.red
        }
       else if (vrednost > 0.2) && (vrednost <= 0.4)
        {
            funLabel.text! = "Fun: Bad"
            funValue = 2
            funSlider.tintColor = UIColor.orange
            funSlider.thumbTintColor = UIColor.orange
        }
        else if (vrednost > 0.4) && (vrednost <= 0.6)
        {
            funLabel.text! = "Fun: Mediocore"
            funValue = 3
            funSlider.tintColor = UIColor.blue
            funSlider.thumbTintColor = UIColor.blue
        }
        else if (vrednost > 0.6) && (vrednost <= 0.8)
        {
            funLabel.text! = "Fun:Good"
            funValue = 4
            funSlider.tintColor = UIColor.yellow
            funSlider.thumbTintColor = UIColor.yellow
        }else{
            funValue = 5
            funLabel.text! = "Fun: Excellent"
            funSlider.tintColor = UIColor.green
            funSlider.thumbTintColor = UIColor.green
        }
    }
    
    @IBAction func rateButton(_ sender: UIButton) {
        
        let carRPost = PFObject(className: "carReview")
        
        carRPost["model"] = carModelGlobal
        carRPost["make"] = carMakeGlobal
        carRPost["fuelEconomy"] = fuelValue 
        carRPost["reliability"] = reliabilityValue
        carRPost["fun"] = funValue
        carRPost["handling"] = handlingValue
        carRPost["valueForMoney"] = valueValue
        carRPost["looks"] = looksValue
        carRPost["userEmail"] = userEmail
        
        carRPost.saveInBackground {(success: Bool, error: Error?) in
            if success
            {
                print("successfuly posted the car review post")
                self.createAlert(title: "Success", message: "The car review post is uploaded to server")
            }
            else
            {
                if error?.localizedDescription != nil
                {
                    print("ERROR!!!: " + (error?.localizedDescription)!)
                    self.createAlert(title: "error", message: (error?.localizedDescription)!)
                }
                else
                {
                    print("ERROR!!!: unknown")
                    self.createAlert(title: "error", message: "unkown")
                }
            }
        }
        print("back to my cars")
        performSegue(withIdentifier: "ratingToMyCarsSeg", sender: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        print("rating view loaded")
        
        navBar.title = carMakeGlobal + carModelGlobal
        
    }
    @IBAction func backButton(_ sender: UIButton) {
        print("back to my cars")
        performSegue(withIdentifier: "ratingToMyCarsSeg", sender: nil)
    }
    
    func createAlert(title: String, message: String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert )
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
    }
}
