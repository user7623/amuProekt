//
//  AdminCarsViewController.swift
//  carReview
//
//  Created by iIdiot on 1/7/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse

class AdminCarsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var adminCarsArray: [PFObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        carsTableView.dataSource = self
        carsTableView.delegate = self
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let carQ = PFQuery(className: "car")
        
        carQ.findObjectsInBackground(block: {(result: [PFObject]? , error: Error?)-> Void in
            if let foundCars = result
            {
                self.adminCarsArray = foundCars
                if self.adminCarsArray.count <= 0 {print("problem, no cars found!")}
                else{
                    print("loading table data, " + "\(self.adminCarsArray.count)" + "cars found")
                    self.carsTableView.reloadData()
                }
            }else
            {
                if let erMsg = error
                {
                    print(erMsg.localizedDescription)
                }
                else
                {
                    print("Problem!! Unknown error!!!")
                }
            }
        })
    }
    @IBAction func backButton(_ sender: UIButton) {
        print("back to new car view")
        performSegue(withIdentifier: "carsToNewCarSeg", sender: nil)
    }
    
    @IBAction func usersButton(_ sender: UIButton) {
        print("to users")
        performSegue(withIdentifier: "goToUserSeg", sender: nil)
    }
    @IBOutlet var carsTableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return adminCarsArray.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "adminKelija", for: indexPath)
        cell.textLabel?.text! = adminCarsArray[indexPath.row].object(forKey: "make") as! String
        cell.detailTextLabel?.text! = adminCarsArray[indexPath.row].object(forKey: "model") as! String
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedCarByClient = adminCarsArray[indexPath.row]
        
        performSegue(withIdentifier: "carsToCarDetailSeg", sender: nil)
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            adminCarsArray[indexPath.row].deleteInBackground()
            adminCarsArray.remove(at: indexPath.row)
            carsTableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.bottom)
          //  carsTableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let pom = adminCarsArray[destinationIndexPath.row]
        adminCarsArray[destinationIndexPath.row] = adminCarsArray[sourceIndexPath.row]
        adminCarsArray[sourceIndexPath.row] = pom
        
        carsTableView.moveRow(at: sourceIndexPath, to: destinationIndexPath)
        //tableView.reloadData()
    }
    
    
}
