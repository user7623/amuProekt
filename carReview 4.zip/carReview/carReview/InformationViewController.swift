//
//  InformationViewController.swift
//  carReview
//
//  Created by iIdiot on 1/8/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse
import youtube_ios_player_helper
class InformationViewController: UIViewController, UIGestureRecognizerDelegate/*,YTPlayerViewDelegate */{

    @IBOutlet var nYTPlayer: YTPlayerView!
    
    @IBOutlet var starOneImageView: UIImageView!
    @IBOutlet var startTwoImageView: UIImageView!
    @IBOutlet var starThreeImageView: UIImageView!
    @IBOutlet var starFourImageView: UIImageView!
    @IBOutlet var starFiveImageView: UIImageView!
    @IBOutlet var ratingTextLabel: UILabel!
    @IBOutlet var basedOnLabel: UILabel!
    @IBOutlet var swipeLabel: UILabel!
    @IBAction func backButton(_ sender: UIButton) {
        print("back button pressed")
        performSegue(withIdentifier: "infoToCarDetailsSeg", sender: nil)
    }
    
    @IBAction func homeButton(_ sender: UIButton) {
        print("homeButton pressed")
        performSegue(withIdentifier: "infoToHomeSeg", sender: nil)
    }
    
    @IBAction func logoutButton(_ sender: UIButton) {
        print("logout button pressed")
        
        //let sv = UIViewController.displaySpinner(onView: self.view)
        PFUser.logOutInBackground{(error: Error?) in
            //UIViewController.removeSpinner(spinner: sv)
            if error == nil
            {
                print("logout success")
                self.performSegue(withIdentifier: "infoToLoginSeg", sender: self)
            }else{
                if error?.localizedDescription != nil
                {
                    print("error: " + (error?.localizedDescription)!)
                }else{
                    print("unkonw error!!!")
                }
            }
        }
        //performSegue(withIdentifier: "infoToLoginSeg", sender: nil)
    }
    
    var averageFuel = 0
    var averageRel = 0
    var averageLooks = 0
    var averageValue = 0
    var averageHandling = 0
    var averageFun = 0
    var model = ""
    var make = ""
    var revCount = 0
    var showRatingSelected = 1
    var commentRev = ["Poor", "Bad", "Mediocore","Good", "Excellent"]
    var reviewsArray: [PFObject] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        print("view for information did load")
        
        print("fetching video")
        //nYTPlayer.delegate = self
        nYTPlayer.load(withVideoId: "XlyImuo-IBw")
        //nYTPlayer.load(withVideoId: "zX4hXWYLhPo", playerVars: ["playsinline" : 1])
        print("video loaded")
        let leftGesture = UISwipeGestureRecognizer(target: self, action: #selector(funkcijaZaGesture(gestrureR:)))
        
        leftGesture.direction = .left
        
        leftGesture.delegate = self
        self.view.addGestureRecognizer(leftGesture)
        
        let rightGesture = UISwipeGestureRecognizer(target: self, action: #selector(funkcijaZaGesture(gestrureR:)))
        rightGesture.direction = .right
        
        self.view.addGestureRecognizer(rightGesture)
        rightGesture.delegate = self
        
        print("gesture recognizer set")
        
        
        starOneImageView.isHidden = true
        startTwoImageView.isHidden = true
        starThreeImageView.isHidden = true
        starFourImageView.isHidden = true
        starFiveImageView.isHidden = true
        model = selectedCarByClient?.object(forKey: "model") as! String
        make = selectedCarByClient?.object(forKey: "make") as! String
        
        print("fetching info for :" + model + " " + make)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        print("view did appear")
        let carQ = PFQuery(className: "carReview")
        carQ.whereKey("model", equalTo: model)
        carQ.findObjectsInBackground(block: {(result: [PFObject]? , error: Error?)-> Void in
            if let foundCars = result //as? [PFObject]
            {
                self.revCount = self.reviewsArray.count
                self.reviewsArray = foundCars
                if self.reviewsArray.count <= 0
                {
                    print("problem, no cars found!")
                    
                }
                else{
                    self.revCount = self.reviewsArray.count
                    let pomRevCount = self.revCount
                    while self.revCount > 0
                    {
                        let funPom = self.reviewsArray[self.revCount - 1].object(forKey: "fun") as! Int
                        self.averageFun = self.averageFun + funPom
                        let fuelPom = self.reviewsArray[self.revCount - 1].object(forKey: "fuelEconomy") as! Int
                        self.averageFuel = self.averageFuel + fuelPom
                        let looksPom = self.reviewsArray[self.revCount - 1].object(forKey: "looks") as! Int
                        self.averageLooks = self.averageLooks + looksPom
                        let handlingPom = self.reviewsArray[self.revCount - 1].object(forKey: "handling") as! Int
                        self.averageHandling = self.averageHandling + handlingPom
                        let relPom = self.reviewsArray[self.revCount - 1].object(forKey: "reliability") as! Int
                        self.averageRel = self.averageRel + relPom
                        let valuePom = self.reviewsArray[self.revCount - 1].object(forKey: "valueForMoney") as! Int
                        self.averageValue = self.averageValue + valuePom
                        
                        self.revCount = self.revCount - 1
                        
                    }
                    self.averageFun = self.averageFun / pomRevCount
                    self.averageFuel = self.averageFuel / pomRevCount
                    self.averageLooks = self.averageLooks / pomRevCount
                    self.averageHandling = self.averageHandling / pomRevCount
                    self.averageRel = self.averageRel / pomRevCount
                    self.averageValue = self.averageValue / pomRevCount
                    
                    print("average rating by clients calculated")
                    self.adjustTheViewFunction()
                    
                    self.revCount = self.reviewsArray.count
                    self.basedOnLabel.text! = "Based on " + "\(self.revCount)" + "owner reviews"
                }
            }else
            {
                if let erMsg = error
                {
                    print(erMsg.localizedDescription)
                }
                else
                {
                    print("Problem!! Unknown error!!!")
                }
            }
        })
    }

    @objc func funkcijaZaGesture(gestrureR: UISwipeGestureRecognizer){
        if gestrureR.direction == .left {
            //labela.text = "Premin vo levo"
            print("direction is LEFT")
            if showRatingSelected == 1
            {
                showRatingSelected = 6
            }
            else
            {
                showRatingSelected = showRatingSelected - 1
            }
        }
        if gestrureR.direction == .right {
            //labela.text = "Premin vo desno"
            print("direction is RIGHT")
            if showRatingSelected == 6
            {
                showRatingSelected = 1
            }else{
                showRatingSelected = showRatingSelected + 1
            }
        }
        adjustTheViewFunction()
    }

    func adjustTheViewFunction()
    {
        //var pom = 0
        if showRatingSelected == 1
        {
            ratingTextLabel.text! = "Fuel economy is " + "\(averageFuel)"
            if averageFuel == 1
            {
                oneStar()
            }else if averageFuel == 2
            {
                twoStar()
            }else if averageFuel == 3
            {
                threeStar()
            }else if averageFuel == 4
            {
                fourStar()
            }else
            {
                fiveStar()
            }
        }
        if showRatingSelected == 2
        {
            ratingTextLabel.text! = "Reiability is " + "\(averageRel)"
            if averageRel == 1
            {
                oneStar()
            }else if averageRel == 2
            {
                twoStar()
            }else if averageRel == 3
            {
                threeStar()
            }else if averageRel == 4
            {
                fourStar()
            }else
            {
                fiveStar()
            }
        }
        if showRatingSelected == 3
        {
            ratingTextLabel.text! = "Appearance is " + "\(averageLooks)"
            if averageLooks == 1
            {
                oneStar()
            }else if averageLooks == 2
            {
                twoStar()
            }else if averageLooks == 3
            {
                threeStar()
            }else if averageLooks == 4
            {
                fourStar()
            }else
            {
                fiveStar()
            }
        }
        if showRatingSelected == 4
        {
            ratingTextLabel.text! = "Value for money is " + "\(averageValue)"
            if averageValue == 1
            {
                oneStar()
            }else if averageValue == 2
            {
                twoStar()
            }else if averageValue == 3
            {
                threeStar()
            }else if averageValue == 4
            {
                fourStar()
            }else
            {
                fiveStar()
            }
        }
        if showRatingSelected == 5
        {
            ratingTextLabel.text! = "Handling is " + "\(averageFuel)"
            if averageHandling == 1
            {
                oneStar()
            }else if averageHandling == 2
            {
                twoStar()
            }else if averageHandling == 3
            {
                threeStar()
            }else if averageHandling == 4
            {
                fourStar()
            }else
            {
                fiveStar()
            }
        }
        if showRatingSelected == 6
        {
            ratingTextLabel.text! = "Fun factor is " + "\(averageFuel)"
            if averageFun == 1
            {
                oneStar()
            }else if averageFun == 2
            {
                twoStar()
            }else if averageFun == 3
            {
                threeStar()
            }else if averageFun == 4
            {
                fourStar()
            }else
            {
                fiveStar()
            }
        }
        print("rating label set")
    }
    func oneStar()
    {
        starOneImageView.isHidden = false
        startTwoImageView.isHidden = true
        starThreeImageView.isHidden = true
        starFourImageView.isHidden = true
        starFiveImageView.isHidden = true
    }
    func twoStar()
    {
        starOneImageView.isHidden = false
        startTwoImageView.isHidden = false
        starThreeImageView.isHidden = true
        starFourImageView.isHidden = true
        starFiveImageView.isHidden = true
    }
    func threeStar()
    {
        starOneImageView.isHidden = false
        startTwoImageView.isHidden = false
        starThreeImageView.isHidden = false
        starFourImageView.isHidden = true
        starFiveImageView.isHidden = true
    }
    func fourStar()
    {
        starOneImageView.isHidden = false
        startTwoImageView.isHidden = false
        starThreeImageView.isHidden = false
        starFourImageView.isHidden = false
        starFiveImageView.isHidden = true
    }
    func fiveStar()
    {
        starOneImageView.isHidden = false
        startTwoImageView.isHidden = false
        starThreeImageView.isHidden = false
        starFourImageView.isHidden = false
        starFiveImageView.isHidden = false
    }
}
