//
//  UsersViewController.swift
//  carReview
//
//  Created by iIdiot on 1/14/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse
class UsersViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    var regUsers:[PFUser?] = []
    
    @IBAction func backButton(_ sender: Any) {
        performSegue(withIdentifier: "backFromUserSeg", sender: nil)
    }
    
    
    @IBOutlet var userstableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("users view loaded")
        userstableView.delegate = self
        userstableView.dataSource = self
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        let userQ = PFQuery(className: "_User")
        userQ.whereKey("admin", equalTo: "NO")
        userQ.findObjectsInBackground(block: {(result: [PFObject]? , error: Error?)-> Void in
            if let foundUsers = result as? [PFUser]
            {
                self.regUsers = foundUsers
                if self.regUsers.count <= 0 {print("problem, no users found!")}
                else{
                    print("loading table data")
                    self.userstableView.reloadData()
                }
            }else
            {
                if let erMsg = error
                {
                    print(erMsg.localizedDescription)
                }
                else
                {
                    print("Problem!! Unknown error!!!")
                }
            }
        })
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return regUsers.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "userCell", for: indexPath)
        cell.textLabel?.text! = regUsers[indexPath.row]!.object(forKey: "username") as! String
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            regUsers[indexPath.row]!.deleteInBackground()
            regUsers.remove(at: indexPath.row)
            userstableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.bottom)

        }
    }
    
}
