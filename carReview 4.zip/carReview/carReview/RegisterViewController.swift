//
//  RegisterViewController.swift
//  carReview
//
//  Created by iIdiot on 1/4/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse

var userEmail = ""
var userCars = ""
var userField = ""
class RegViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {


    var cars = ["Mercedes-A class", "Mercedes-B class", "Mercedes-C class" , "Mercedes-E class", "Mercedes-S class","Mercedes-SLS","Mercedes-G class","Porsche-carrera","Porsche-911","BMW-3xy","BMW-5xy","BMW-7xy","BMW-X5","BMW-X3","BMW-X6","Audi-A7","Audi-A2","Audi-A3","Audi-A4","Audi-A5","Audi-A6","Audi-A8","AlfaRomeo-147","AlfaRomeo-C8","Bentley-continental","Bentley-benteyga","Rolls Royce-phantom","Rolls Royce-ghost","Fiat-500","Fiat-Tepra","Fiat-punto","Jaguar-F type","Jaguar-XKR","Jaguar-E type"]
    var filteredList = ["filtered-search"]
    var firstPick = true
    var isFilteredSearch = false
    var errorTextMessage = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        carsTable.delegate = self
        carsTable.dataSource = self
        
        view.setTwoGradients(colorOne: UIColor.green, colorTwo: UIColor.white)
    }
    var pom = ""
    
    @IBAction func backButton(_ sender: UIButton) {
        performSegue(withIdentifier: "backFromRegisterView", sender: nil)
    }
    
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var confirmPasswordTextField: UITextField!
    @IBOutlet var carsTable: UITableView!
    @IBOutlet var infoLabel: UILabel!
    @IBOutlet var filterTextField: UITextField!
    
    @IBAction func filterButton(_ sender: UIButton) {
        
        if filterTextField.text! != ""
        {
            pom = filterTextField.text!
            isFilteredSearch = true
            carsTable.reloadData()
        }
        
        
    }
    
    
    
    @IBAction func registerButton(_ sender: UIButton) {
        
        if emailTextField.text! == ""
        {
            errorTextMessage = "email is requered!"
        }
        else if passwordTextField.text! == ""
        {
            errorTextMessage = "password is requered!"
        }
        else if confirmPasswordTextField.text! == ""
        {
            errorTextMessage = "name&surname is requered!"
        }
        else if infoLabel.text! == ""
        {
            errorTextMessage = "Dont forget to select at least one previously owned car"
        }
        else
        {
            print("creating new user")
            let user = PFUser()
            user.password = passwordTextField.text!
            user.email = emailTextField.text!
            user.username = emailTextField.text!
            user["cars"] = infoLabel.text!
            user["admin"] = "NO"
            print("starting saveInBackground")
            user.signUpInBackground { (success, error) in
                UIApplication.shared.endIgnoringInteractionEvents()
                if let error = error {
                    print("error")
                    let errorString = error.localizedDescription
                    print("localized error: " + errorString)
                    self.infoLabel.text! = "Server error"
                } else {
                        print("Sign up success!")
                        userEmail = user["email"] as! String
                        userCars = user["cars"] as! String
                        self.performSegue(withIdentifier: "toClientViewReg", sender: self)
                    }
                }
            }
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cars.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Kelija", for: indexPath)
        if isFilteredSearch
        {
            var carsCount = cars.count
            while carsCount > 0
            {
                if cars[carsCount - 1].lowercased().contains(pom.lowercased())
                {
                    filteredList.append(cars[carsCount])
                }
                carsCount = carsCount - 1
            }
            if filteredList.count < 1 {print("no such cars found")}else{
                let vrednosti = filteredList[indexPath.row].components(separatedBy: "-")
                cell.textLabel?.text = vrednosti[0]
                cell.detailTextLabel?.text = vrednosti[1]
            }
        }else{
            let vrednosti = cars[indexPath.row].components(separatedBy: "-")
            cell.textLabel?.text = vrednosti[0]
            cell.detailTextLabel?.text = vrednosti[1]
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        let prvT = cell?.textLabel?.text!
        let vtorT = cell?.detailTextLabel?.text!
        let pom = prvT! + "-" + vtorT! + "|"
        let selectionOfClient = infoLabel.text!.components(separatedBy: "|")
        let countV = selectionOfClient.count
        if firstPick
        {
            infoLabel.text! = ""
            firstPick = false
        }
        
        if countV < 3
        {
            infoLabel.text!.append(pom)
        }else{
            let prviot = selectionOfClient[1]
            let vtoriot = selectionOfClient[2]
            infoLabel.text! = prviot + "|" + vtoriot + "|" + pom
        }
    }
    
}
