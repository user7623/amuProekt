//
//  CarDetailsViewController.swift
//  carReview
//
//  Created by iIdiot on 1/7/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse
class CarDetailsViewController: UIViewController, UIGestureRecognizerDelegate {

    //razlicen seg za admin i client!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("view car details viewDidLoad")
        
        print("pre img")
        
        carImageView = UIImageView(image: carImageSelectedGlobal)
        self.view.addSubview(carImageView)
        let frame = CGRect(x: 5, y: 230, width: self.view.frame.width - 10, height: 230)
        self.carImageView.frame = frame
        print("post img")
    }
    @IBAction func backButton(_ sender: UIButton) {
        if userField == "YES"
        {
            print("is admin to admin cars view")
            performSegue(withIdentifier: "carDetailToCarsSeg"
                , sender: nil)
        }else{
            print("is client, to client main view")
            performSegue(withIdentifier: "carDetailsToClientViewSeg", sender: nil)
        }
    }
    @IBOutlet var makeLabel: UILabel!
    @IBOutlet var yearLabel: UILabel!
    @IBOutlet var modelLabel: UILabel!
    @IBOutlet var PriceLabel: UILabel!
    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var carImageView: UIImageView!
    
    override func viewDidAppear(_ animated: Bool) {
        print("car details view did appear")
        makeLabel.text!.append(selectedCarByClient?.object(forKey: "make") as! String)
        print(makeLabel.text!)
        yearLabel.text!.append(selectedCarByClient?.object(forKey: "year") as! String)
        print(yearLabel.text!)
        modelLabel.text!.append(selectedCarByClient?.object(forKey: "model") as! String)
        PriceLabel.text!.append(selectedCarByClient?.object(forKey: "price") as! String)
        descriptionLabel.text! = selectedCarByClient?.object(forKey: "description") as! String
        print("txt data loaded")
        //let data = selectedCarByClient?.object(forKey: "carImage") as! Data
        //let vechicleImage = UIImage(data: data)
        print("fetching image")
        
        let modelPom = selectedCarByClient?.object(forKey: "model") as! String
        print("%%" + modelPom)
       
        print("car details loaded")
        
        let leftGesture = UISwipeGestureRecognizer(target: self, action: #selector(funkcijaZaGesture(gestrureR:)))
        
        leftGesture.direction = .left
        
        leftGesture.delegate = self
        self.view.addGestureRecognizer(leftGesture)
        
        let rightGesture = UISwipeGestureRecognizer(target: self, action: #selector(funkcijaZaGesture(gestrureR:)))
        rightGesture.direction = .right
        
        self.view.addGestureRecognizer(rightGesture)
        rightGesture.delegate = self
        
        print("gesture recognizer set")
        
        
    }
    @objc func funkcijaZaGesture(gestrureR: UISwipeGestureRecognizer){
        if gestrureR.direction == .left {
            //labela.text = "Premin vo levo"
            print("direction is LEFT")
     
        }
        if gestrureR.direction == .right {
            //labela.text = "Premin vo desno"
            print("direction is RIGHT")
            performSegue(withIdentifier: "carDetailsToRatingSeg", sender: nil)
         
        }
    }

    
    
//carDetailsToRatingSeg
    
}
