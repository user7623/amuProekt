//
//  MyCarsViewController.swift
//  carReview
//
//  Created by iIdiot on 1/7/21.
//  Copyright © 2021 iIdiot. All rights reserved.
//

import UIKit
import Parse

var carMakeGlobal = ""
var carModelGlobal = ""

class MyCarsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var numOfCars = 0
    var carsDetail:[PFObject] = []
    var myCarsList:[PFObject] = []
   
    @IBAction func backButton(_ sender: UIButton) {
        print("Back to main client view")
        performSegue(withIdentifier: "myCarsToClientViewSeg", sender: nil)
    }
    @IBAction func addButton(_ sender: UIButton) {
    }
    @IBOutlet var myCarsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("View my cars did load")
        myCarsTableView.dataSource = self
        myCarsTableView.delegate = self
    }
    override func viewDidAppear(_ animated: Bool) {
        print("view did appear")
        let carQ = PFQuery(className: "car")
        carQ.findObjectsInBackground(block: {(result: [PFObject]? , error: Error?)-> Void in
            if let foundCars = result //as? [PFObject]
            {
                self.carsDetail = foundCars
                let cCount = self.carsDetail.count
                print("number of found cars is: " + "\(cCount)")
                if self.carsDetail.count <= 0 {print("problem, no cars found!")}
                else{
                    print("geting informations")
                    var carCount = self.carsDetail.count
                    let myCarsArray = userCars.components(separatedBy: "|")
                    var numOfUserCars = myCarsArray.count
                    print("client cars " + "\(numOfUserCars)")
                    while numOfUserCars > 1
                    {
                        print("\(numOfUserCars)" + "->" + myCarsArray[numOfUserCars - 1])
                        numOfUserCars = numOfUserCars - 1
                    }
                    numOfUserCars = myCarsArray.count
                    while carCount > 0
                    {
                        var nMake = self.carsDetail[carCount - 1].object(forKey: "make") as! String
                        var nModel = self.carsDetail[carCount - 1].object(forKey: "model") as! String
                        var nvalue = nMake + "-" + nModel
                        print("nvalue: " + nvalue)
              
                        while numOfUserCars > 0
                        {
                            print("needed value: " + myCarsArray[numOfUserCars - 1])
                            
                            if myCarsArray[numOfUserCars - 1] == nvalue
                            {
                                print("added to list")
                                self.myCarsList.append(self.carsDetail[numOfUserCars - 1])
                            }
                            numOfUserCars = numOfUserCars - 1
                        }
                        numOfUserCars = myCarsArray.count
                        nMake = ""
                        nModel = ""
                        nvalue = ""
                        carCount = carCount - 1
                        print("......................................")
                    }
                    print("info loaded for car list")
                    self.myCarsTableView.reloadData()
                    print("reloading table data")
                }
            }else{
                if let erMsg = error
                {
                    print(erMsg.localizedDescription)
                }
                else
                {
                    print("Problem!! Unknown error!!!")
                }
            }
            print("+++++++++++")
            self.myCarsTableView.reloadData()
        })
        print("**********")
        myCarsTableView.reloadData()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myCarsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("cell for row at --------------------------------")
        let cell = tableView.dequeueReusableCell(withIdentifier: "clientCarKelija", for: indexPath)
        cell.textLabel?.text! = myCarsList[indexPath.row].object(forKey: "make") as! String
        cell.detailTextLabel?.text! = myCarsList[indexPath.row].object(forKey: "model") as! String
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("selected a row")
        print("\(indexPath.row)")
        let cell = tableView.dequeueReusableCell(withIdentifier: "clientCarKelija", for: indexPath)
        
        carMakeGlobal = self.myCarsList[indexPath.row].object(forKey: "make") as! String
        carModelGlobal = self.myCarsList[indexPath.row].object(forKey: "model") as! String
        print("global make: " + carMakeGlobal + " model: " + carModelGlobal)
        print("going to rating view")
        performSegue(withIdentifier: "myCarsToRatingViewSeg", sender: nil)
    }
}
